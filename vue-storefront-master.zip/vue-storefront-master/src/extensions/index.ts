/** 
 * If you have some extensions that are not yet ported to modules you can register them here
 * Keep in mind that extensions will be depreciated in next versions of Vue Storefront and replaced by modules
 */
export const registerExtensions = []