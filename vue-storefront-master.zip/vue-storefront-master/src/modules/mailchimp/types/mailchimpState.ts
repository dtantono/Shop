export interface mailchimpState {
  isSubscribed: boolean | null,
  email: string | null
}