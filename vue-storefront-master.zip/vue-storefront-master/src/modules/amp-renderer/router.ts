import AmpThemeRouting from 'src/themes/default-amp/router'	
export default AmpThemeRouting