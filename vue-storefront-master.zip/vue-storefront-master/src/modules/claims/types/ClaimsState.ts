export default interface ClaimsState {
}