import { UserShippingDetails } from '@vue-storefront/core/modules/user/components/UserShippingDetails'
export default {
  mixins: [UserShippingDetails]
}
