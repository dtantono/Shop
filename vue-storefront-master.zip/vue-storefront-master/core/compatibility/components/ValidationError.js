// theme-specific component
export default {
  name: 'ValidationError',
  props: {
    message: {
      type: String,
      default: ''
    }
  }
}
