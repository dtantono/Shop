import server from './server.js';

export default server;
