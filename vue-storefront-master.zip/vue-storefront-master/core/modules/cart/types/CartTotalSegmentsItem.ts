export default interface CartTotalSegmentsItem {
  code: string,
  title: string,
  value: number,
  area?: string,
  extension_attributes?: object
}
