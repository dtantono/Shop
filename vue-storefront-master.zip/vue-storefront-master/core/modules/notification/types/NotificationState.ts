import NotificationItem from './NotificationItem'

export default interface NotificationState {
  notifications: NotificationItem[]
}
