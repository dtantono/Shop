import '../modules/offline-order/extends/service-worker.js'
import 'theme/service-worker/index.js'

// core service worker, all service worker related features are placed here.
