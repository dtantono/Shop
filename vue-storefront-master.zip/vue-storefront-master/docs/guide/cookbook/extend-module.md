# Chapter 5. Extend a module 

## Coming soon!
